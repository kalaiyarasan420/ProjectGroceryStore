package com.grocery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grocery.model.Grocery;

@Repository 

public interface GroceryRepository extends JpaRepository<Grocery,Integer>{
	
	
	//Derived queries
		public List<Grocery> findByName(String name);
		
		
		//Positional
		@Query("select g from Grocery g where g.name=?1 and g.costprice=?2")
		public List<Grocery> getGroceryByCostprice(String name,double costprice);
		
		
		//Named
		@Query("select g from Grocery g where g.sellingprice=:sellingprice")
		public List<Grocery> getGroceryBySell(double sellingprice);
		
		//Native
		@Query(value="select * from Grocery g where g.quantity=?1",nativeQuery=true)
		public List<Grocery> fetchGroceryByQuantity(int quantity);

		//DML
		@Modifying
		@Query("delete from Grocery g where g.name=?1" )
		public int deleteGroceryByName(String name);

		@Modifying
		@Query("update Grocery g set g.name=?1 where g.costprice=?2")
		public int updateGroceryByCost(String name,double costprice);
        
}