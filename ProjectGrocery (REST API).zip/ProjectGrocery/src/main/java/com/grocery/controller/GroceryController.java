package com.grocery.controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
//import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grocery.model.Grocery;
import com.grocery.model.LoginModel;
import com.grocery.model.Orders;
import com.grocery.service.GroceryService;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController

public class GroceryController {
	@Autowired
	GroceryService groceryService;
	
	@Tag(name="Get", description="get data")
	@GetMapping("/get")
	public List<Grocery> getGroceryDetails(){
		return groceryService.getGroceryDetails();
	}
	
	@Tag(name="Post", description="post data")
	@PostMapping("/post")
	public Grocery postGroceryDetails(@RequestBody Grocery G) {
		return groceryService.postGroceryDetails(G);
	}	
	
	@Tag(name="Put", description="put data")
	@PutMapping("/put")
	public Grocery updateGroceryDetails(@RequestBody Grocery G) {
		return groceryService.updateGroceryDetails(G);
	}
	
	@Tag(name="Delete", description="delete data")
	@DeleteMapping("/delete/{id}")
	public String deleteGroceryDetails(@PathVariable("id") int id) {
		return groceryService.deleteGroceryDetails(id);
	}
	
	
	@GetMapping(value="/sortGrocery/{field}")
	public List<Grocery> sortGrocery(@PathVariable String field)
	{
		return groceryService.grocerysort(field);
	}
	
	
	@GetMapping(value="/pageGrocery/{offset}/{pagesize}")
	public Page<Grocery> getGrocerydetails(@PathVariable int offset,@PathVariable int pagesize)
	{
		return groceryService.getGrocery(offset,pagesize);
	}
	
	
	@GetMapping(value="/pageGrocery1/{offset}/{pagesize}")
	public List<Grocery> getGrocerydetail(@PathVariable int offset,@PathVariable int pagesize)
	{
		return groceryService.getGroceryDetail(offset,pagesize);
	}
	
	
	@GetMapping("/pagingAndSortingRegistrationDb/{offset}/{pageSize}/{field}")
	public List<Grocery> pagingAndSortingRegistrationDb(@PathVariable int offset,@PathVariable int pageSize,@PathVariable String field)
	{
		return groceryService.pagingAndSortingRegistrationDb(offset,pageSize,field);
	}
	
	
	@GetMapping(value="/getLogin")
	public List<LoginModel> getLogin()
	{
		return groceryService.getLogin();
	}
	
	@PostMapping("/login")
	public String loginModel(@RequestBody Map<String,String> loginDataMap)
			{
				String username = loginDataMap.get("username");
				String password = loginDataMap.get("password");
				String result = groceryService.validateUser(username, password);
				return result;
			}
	
	
	
	//derived queries
		@GetMapping("/getByName/{name}")
		public List<Grocery> findByCategoryId(@PathVariable String name)
		{
			return groceryService.findByName(name);
		}
		
		
		//Query positional
		@GetMapping("/getGroceryByCostprice/{name}/{costprice}")
		public List<Grocery> getGroceryByCostprice(@PathVariable String name,@PathVariable double costprice)
		{
			return groceryService.getGroceryByCostprice(name, costprice);
		}
		

		

		//Named
		@GetMapping("/getGroceryBySell/{sellingprice}")
		public List<Grocery> getGroceryBySell(@PathVariable double sellingprice)
		{
			return groceryService.getGroceryBySell(sellingprice);
		}
		
		
		//native
		@GetMapping("/getByServing/{serving}")
		public List<Grocery> fetchGroceryByQuantity(@PathVariable int quantity)
		{
			return groceryService.fetchGroceryByQuantity(quantity);
		}
		
		
		//DML
		@DeleteMapping("/deleteGroceryByName/{name}")
		public String deleteGroceryByName(@PathVariable String name)
		{
			int result=groceryService.deleteGroceryByName(name);
			if(result>0)
			{
				return "Recipe record deleted";
			}
			else
			{
				return "Problem occured while deleting";
			}
		}
		

		@PutMapping("/updateGroceryByCost/{cuisine}/{recipeName}")
		public String updateGroceryByCost(@PathVariable String name,@PathVariable int quantity)
		{
			int result=groceryService.updateGroceryByCost(name,quantity);
			if(result>0)
			{
				return "Recipe record updated";
			}
			else
			{
				return "Problem occured while updating";
			}
		}

	
}
	
