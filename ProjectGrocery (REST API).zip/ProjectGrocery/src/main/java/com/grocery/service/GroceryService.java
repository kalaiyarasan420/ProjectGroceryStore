package com.grocery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.model.Grocery;
import com.grocery.model.LoginModel;
import com.grocery.model.Orders;
import com.grocery.repository.GroceryRepository;
import com.grocery.repository.LoginRepo;
import com.grocery.repository.OrderRepo;
import com.grocery.repository.RegistrationRepo;

@Service
public class GroceryService {
	@Autowired
	GroceryRepository groceryRepository;
	@Autowired
	RegistrationRepo registrationRepo;
	@Autowired
	LoginRepo loginRepo;
	@Autowired
	OrderRepo orderRepo;
	
	public List<Grocery> getGroceryDetails(){
		return groceryRepository.findAll();
	}
	public Grocery postGroceryDetails(Grocery G) {
		return groceryRepository.save(G);
	}
	public Grocery updateGroceryDetails(Grocery G) {
		return groceryRepository.save(G);
	}
	public String deleteGroceryDetails(int id) {
		groceryRepository.deleteById(id);
		return "Id : "+id+" is deteled";
	}
	
	public List<Grocery> grocerysort(String field) {
        return groceryRepository.findAll(Sort.by(field).ascending());
		 //return groceryRepository.findAll(Sort.by(field).descending());
	}
	
	public List<Grocery> getGroceryDetail(int offset,int pageSize) {
		Pageable paging = PageRequest.of(offset, pageSize);
		Page<Grocery> regData=groceryRepository.findAll(paging);
		List<Grocery> regList=regData.getContent();
			return regList;
		}
	
	public Page<Grocery> getGrocery(int offset, int pageSize) {
		Pageable paging = PageRequest.of(offset, pageSize);
		Page <Grocery> groData=groceryRepository.findAll(paging);
		return groData;
	}
	
	public List<Grocery> pagingAndSortingRegistrationDb(int offset,int pageSize,String field) {
		Pageable paging = PageRequest.of(offset, pageSize).withSort(Sort.by(field));
		//Pageable paging = PageRequest.of(offset, pageSize).withSort(Sort.by(Direction.DESC,field));
			Page<Grocery> reg=groceryRepository.findAll(paging);
			return reg.getContent();
		}
	
	public List<LoginModel> getLogin()
	{
		return loginRepo.findAll();
	}
	public LoginModel saveLogin(LoginModel m)
	{
		return loginRepo.save(m);
	}
	public String validateUser(String username,String password)
	{
		String result="";
		LoginModel m=loginRepo.findByUsername(username);
		if(m==null)
		{
			result="Invalid user";
		}
		else
		{
				if(m.getPassword().equals(password))
				{
					result="Login success";
				}
				else
				{
					result="Login failed";
				}
		}
		return result;
	}
		
    
	//Derived queries
		public List<Grocery> findByName(String name)
		{
			return groceryRepository.findByName(name);
		}
		
		
		//Query positional
		public List<Grocery> getGroceryByCostprice(String name, double costprice)
		{
			return groceryRepository.getGroceryByCostprice(name, costprice);
		}

		
		//named
		public List<Grocery> getGroceryBySell(double sellingprice)
		{
			return groceryRepository.getGroceryBySell(sellingprice);
		}
		
		
		//native
		public List<Grocery> fetchGroceryByQuantity(int quantity)
		{
			return groceryRepository.fetchGroceryByQuantity(quantity);
		}
		
		
		//DML
		@Transactional
		public int deleteGroceryByName(String name)
		{
			return groceryRepository.deleteGroceryByName(name);
		}
		
		@Transactional
		public int updateGroceryByCost(String name, int quantity)
		{
			return groceryRepository.updateGroceryByCost(name,quantity);
		}
	
}