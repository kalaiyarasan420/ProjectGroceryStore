package com.grocery.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Orders {

	@Id
	
	private int Order_id;
	private String Payment_Method;
	private int Order_time;
	private int Billing_id;
	private double Amount;
	private int Shipping_id;
	private int Address_id;
	private int User_id;
	public Orders() {
		super();
	}
	public Orders(int order_id, String payment_Method, int order_time, int billing_id, double amount, int shipping_id,
			int address_id, int user_id) {
		super();
		Order_id = order_id;
		Payment_Method = payment_Method;
		Order_time = order_time;
		Billing_id = billing_id;
		Amount = amount;
		Shipping_id = shipping_id;
		Address_id = address_id;
		User_id = user_id;
	}
	public int getOrder_id() {
		return Order_id;
	}
	public void setOrder_id(int order_id) {
		Order_id = order_id;
	}
	public String getPayment_Method() {
		return Payment_Method;
	}
	public void setPayment_Method(String payment_Method) {
		Payment_Method = payment_Method;
	}
	public int getOrder_time() {
		return Order_time;
	}
	public void setOrder_time(int order_time) {
		Order_time = order_time;
	}
	public int getBilling_id() {
		return Billing_id;
	}
	public void setBilling_id(int billing_id) {
		Billing_id = billing_id;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public int getShipping_id() {
		return Shipping_id;
	}
	public void setShipping_id(int shipping_id) {
		Shipping_id = shipping_id;
	}
	public int getAddress_id() {
		return Address_id;
	}
	public void setAddress_id(int address_id) {
		Address_id = address_id;
	}
	public int getUser_id() {
		return User_id;
	}
	public void setUser_id(int user_id) {
		User_id = user_id;
	}
	
}
