package com.grocery.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class RegistrationModel {
	@Id
	private int    CustomerId;
	private String CustomerName;
	private String CustomerGender;
	private long   CustomerNumber;
	private String CustomerCity;
	private String CustomerAddress;
	private String CustomerDob;
	private String CustomerEmail;
	private long   CityPincode;
	private Double TotalCost;
	public int getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getCustomerGender() {
		return CustomerGender;
	}
	public void setCustomerGender(String customerGender) {
		CustomerGender = customerGender;
	}
	public long getCustomerNumber() {
		return CustomerNumber;
	}
	public void setCustomerNumber(long customerNumber) {
		CustomerNumber = customerNumber;
	}
	public String getCustomerCity() {
		return CustomerCity;
	}
	public void setCustomerCity(String customerCity) {
		CustomerCity = customerCity;
	}
	public String getCustomerAddress() {
		return CustomerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		CustomerAddress = customerAddress;
	}
	public String getCustomerDob() {
		return CustomerDob;
	}
	public void setCustomerDob(String customerDob) {
		CustomerDob = customerDob;
	}
	public String getCustomerEmail() {
		return CustomerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		CustomerEmail = customerEmail;
	}
	public long getCityPincode() {
		return CityPincode;
	}
	public void setCityPincode(long cityPincode) {
		CityPincode = cityPincode;
	}
	public Double getTotalCost() {
		return TotalCost;
	}
	public void setTotalCost(Double totalCost) {
		TotalCost = totalCost;
	}

	
	public RegistrationModel() {
		super();
	}
	
	
	
	public RegistrationModel(int customerId, String customerName, String customerGender, long customerNumber,
			String customerCity, String customerAddress, String customerDob, String customerEmail, long cityPincode,
			Double totalCost) {
		super();
		CustomerId = customerId;
		CustomerName = customerName;
		CustomerGender = customerGender;
		CustomerNumber = customerNumber;
		CustomerCity = customerCity;
		CustomerAddress = customerAddress;
		CustomerDob = customerDob;
		CustomerEmail = customerEmail;
		CityPincode = cityPincode;
		TotalCost = totalCost;
	}
	
	
	@Override
	public String toString() {
		return "RegistrationModel [CustomerId=" + CustomerId + ", CustomerName=" + CustomerName + ", CustomerGender="
				+ CustomerGender + ", CustomerNumber=" + CustomerNumber + ", CustomerCity=" + CustomerCity
				+ ", CustomerAddress=" + CustomerAddress + ", CustomerDob=" + CustomerDob + ", CustomerEmail="
				+ CustomerEmail + ", CityPincode=" + CityPincode + ", TotalCost=" + TotalCost + "]";
	}
	
	
	
	

}
