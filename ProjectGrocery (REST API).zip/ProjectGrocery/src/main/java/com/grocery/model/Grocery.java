package com.grocery.model;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="grocerydetails")
public class Grocery {
	@Id
	private int id;
	private String name;
	private int quantity;
	private double costprice;
	private double sellingprice;
	private double totalinvestment;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Order_id")
	private Orders orders;
	
	
	
	public Orders getOrders() {
		return orders;
	}
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCostprice() {
		return costprice;
	}
	public void setCostprice(double costprice) {
		this.costprice = costprice;
	}
	public double getSellingprice() {
		return sellingprice;
	}
	public void setSellingprice(double sellingprice) {
		this.sellingprice = sellingprice;
	}
	public double getTotalinvestment() {
		return totalinvestment;
	}
	public void setTotalinvestment(double totalinvestment) {
		this.totalinvestment = totalinvestment;
	}
	
	

}
